# My emotional Palette - #CodePenChallenge : Color Palettes

A Pen created on CodePen.

Original URL: [https://codepen.io/holasoymalva/pen/zxBMNyg](https://codepen.io/holasoymalva/pen/zxBMNyg).

