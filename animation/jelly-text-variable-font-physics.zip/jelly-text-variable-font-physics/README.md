# Jelly text (Variable Font Physics)

A Pen created on CodePen.

Original URL: [https://codepen.io/mike-at-redspace/pen/JoRPvpy](https://codepen.io/mike-at-redspace/pen/JoRPvpy).

